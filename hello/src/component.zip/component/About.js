import React, { Component } from 'react'

export class About extends Component {
  render() {
    return (
      <div>
        <h1>About us page</h1>
      </div>
    )
  }
}

export default About;
