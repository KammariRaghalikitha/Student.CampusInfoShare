import React, { Component } from 'react'

export class Best extends Component {
  render() {
    return (
      <div>
        <h1>Best page</h1>
      </div>
    )
  }
}

export default Best
