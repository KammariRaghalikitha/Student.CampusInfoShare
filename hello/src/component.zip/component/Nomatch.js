import React, { Component } from 'react'

export class Nomatch extends Component {
  render() {
    return (
      <div>
        <h1>Page not found error</h1>
      </div>
    )
  }
}

export default Nomatch;
