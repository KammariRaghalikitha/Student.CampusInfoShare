import React, { Component } from 'react'

export class Service extends Component {
  render() {
    return (
      <div>
        <h1>Servicepage</h1>
      </div>
    )
  }
}

export default Service;
