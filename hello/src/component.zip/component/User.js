import React from 'react'
import {Outlet} from 'react-router-dom'
const User = () => {
  return (
    <div>
      <h1>User 1</h1>
      <h1>USer 2</h1>
      <h1>USer 3</h1>
      <Outlet/>
    </div>
  )
}

export default User