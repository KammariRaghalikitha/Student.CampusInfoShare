import React from 'react'
import {useParams} from 'react-router-dom'
const UserDet = () => {
    const Params=useParams()
    const id=Params.userid
  return (
    <div>
      Details of the user {id}
    </div>
  )
}

export default UserDet;